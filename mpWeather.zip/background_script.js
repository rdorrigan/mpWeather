function createTab(data) {
    return chrome.tabs.create({
        createProperties: { active: data.active },
        url: data.url
    })
}
async function getCurrentTab() {
    let queryOptions = { active: true, lastFocusedWindow: true };
    // `tab` will either be a `tabs.Tab` instance or `undefined`.
    let [tab] = await chrome.tabs.query(queryOptions);
    return tab;
  }

chrome.runtime.onMessage.addListener(
    function(request, sender, sendResponse) {
        console.log(request);
        console.log(sender);
        if (request.message == "createTab") {
            delete request.message;
            chrome.tabs.create(request, function(tab) {
                sendResponse({response: tab});
            });
        } else if (request.message == "getCurrentTab") {
            delete request.message;
            sendResponse({response : getCurrentTab()})
        } else {
            sendResponse({response : "unknown message"})
        }
          
      
      return true; //to tell the content script to look out for sendResponse
  });
