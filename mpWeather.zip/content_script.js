async function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}
// let slept = sleep(3);
// console.log(`slept ${slept} ms`);
const weatherIds = ["weather-forecast", "weather"];
let weatherId;
function getWeatherElement() {
    return document.getElementById(weatherId);
}
function hasForecastElement() {
    var weather = getWeatherElement();
    var hasWeather = (weather !== null);
    console.log(`Page has weather forecast element ${hasWeather}`);
    return hasWeather;
}
function hasWeatherForecast() {
    if (hasForecastElement()) {
        const weather = getWeatherElement();
        // console.log(weather);
        if (document.getElementById("forecast-0") !== null) {
            // if (document.getElementByClassName("weather nws") !== null) {
            console.log("Page has weather forecast");
            return true;
        }
        var weatherMessage = weather.textContent;
        console.log("Weather message ", weatherMessage);
        if ((weatherMessage.match("Sorry|unavailable|\n") !== null) || (weatherMessage === null)) {
            console.log("Page does not have weather forecast");
            return false;
        }
        console.log("Page has weather forecast");
        return true;
    }
    console.log("Page does not have weather forecast");
    return false;
}
function addForecastButton() {
    if ((document.getElementById("get-mp-forecast")) || (hasWeatherForecast())) {
        return false;
    } else if (!hasForecastElement()) {
        return false;
    }

    var forecastElement = getWeatherElement();
    var button = document.createElement("button");
    // button.innerHTML = "TestButton";
    button.type = "button";
    var text = document.createTextNode("Open weather forecast tab");
    button.appendChild(text);
    button.id = "get-mp-forecast";
    // button.visible = true;
    // console.log(button);
    forecastElement.appendChild(button);
    var newButton = document.getElementById("get-mp-forecast");
    newButton.addEventListener('click', function () {
        console.log("forecast button clicked");
        let promise = getWeatherForecast();
        console.log(promise);

    });
    return true;
}
function getLatLon() {
    console.log("getting coordinates");
    var details = document.getElementsByClassName("description-details")[0];
    var gpsTable = details.getElementsByTagName("tr")[1];
    var gpsCoordsText = gpsTable.getElementsByTagName("td")[1].textContent;
    // console.log(gpsCoordsText);
    const gpsMatches = gpsCoordsText.match(/([0-9.-]+).+?([0-9.-]+)/g);
    if (gpsMatches !== null) {
        const coords = [...gpsMatches][0];
        // console.log(coords);
        var splitCoords = coords.split(', ');

        const latitude = splitCoords[0];
        const longitude = splitCoords[1];
        return [latitude, longitude];
    }
    return null;
}

function getWeatherForecastUrl() {
    if (!hasWeatherForecast()) {
        const latLon = getLatLon();
        if (latLon !== null) {
            console.log(latLon);
            const latitude = latLon[0];
            const longitude = latLon[1];
            const forecastUrl = `https://forecast.weather.gov/MapClick.php?lat=${latitude}&lon=${longitude}`;
            // console.log(longitude);
            // console.log(latitude);
            console.log(forecastUrl);
            // chrome.tabs.create({
            //     // createProperties: { active: true },
            //     // callback?: function,
            //     url: forecastUrl//`https://forecast.weather.gov/MapClick.php?lon=${longitude}&lat=${latitude}#.YVIu8bhKg-U`
            // });
            return forecastUrl;
        }
    }
    return null;
}
async function getWeatherForecast() {
    const forecastUrl = getWeatherForecastUrl();
    if (forecastUrl !== null) {
        const response = await chrome.runtime.sendMessage({
            message: "createTab",
            active: true,
            url: forecastUrl
        });
        console.log(response);
        return response;

    }
}
async function getWeatherForecastTab() {
    const forecastUrl = getWeatherForecastUrl();
    if (forecastUrl !== null) {
        // chrome.runtime.onMessage.addListener()
        // let currentTabResponse = await getCurrentTab();
        let currentTabResponse = await chrome.runtime.sendMessage({
            message: "getCurrentTab"
        }).response;
        console.log(currentTabResponse);
        const newTabResponse = await chrome.runtime.sendMessage({
            message: "newTab",
            active: true,
            url: forecastUrl,
            index: currentTabResponse.index + 1
        });
        console.log(newTabResponse);
        return newTabResponse;

    }
}

window.addEventListener('load', function () {
    // alert("It's loaded!")
    console.log("page loaded")
    weatherId = function () {
        for (id of weatherIds) {
            var element = document.getElementById(id);
            if (element !== null) {
                console.log("weather Id is ", id);
                return id;
            }
        }
        console.log("weather Id not found");
        return weatherIds[0];
    }();
    var newButton = addForecastButton();
    if (newButton) {
        console.log("forecast button added");
    }
})
